@echo off
title SillyTavern Installer
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\tavern.ps1" install
echo.
pause
