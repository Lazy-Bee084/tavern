@echo off
title SillyTavern LAN
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\tavern.ps1" lan
echo.
pause
