﻿# SillyTavern 一鍵包 - Windows 主程式
# 用法：tavern.ps1 install | start | update | lan | lanoff
param(
    [ValidateSet('install', 'start', 'update', 'lan', 'lanoff')]
    [string]$Action = 'start'
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # 關掉進度條，下載會快很多
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}

$Root      = Split-Path -Parent $PSScriptRoot
$Runtime   = Join-Path $Root 'runtime'
$NodeDir   = Join-Path $Runtime 'node'
$NodeExe   = Join-Path $NodeDir 'node.exe'
$NpmCmd    = Join-Path $NodeDir 'npm.cmd'
$TavernDir = Join-Path $Root 'SillyTavern'
$TempDir   = Join-Path $Root 'temp'
$BackupDir = Join-Path $Root 'backups'
$CfgFile   = Join-Path $PSScriptRoot 'settings.json'

$RepoGit = 'https://github.com/SillyTavern/SillyTavern.git'
$RepoZip = 'https://github.com/SillyTavern/SillyTavern/archive/refs/heads/release.zip'

$Host.UI.RawUI.WindowTitle = 'SillyTavern 酒館一鍵包'

# ---------- 小工具 ----------
function Say($msg, $color = 'Cyan') { Write-Host $msg -ForegroundColor $color }
function Ok($msg)   { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Fail($msg) {
    Write-Host ""
    Write-Host "  [X]  $msg" -ForegroundColor Red
    Write-Host ""
    exit 1
}

function Load-Settings {
    if (Test-Path $CfgFile) {
        try { return (Get-Content $CfgFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch {}
    }
    return [pscustomobject]@{ mirror = $false }
}
function Save-Settings($s) {
    $s | ConvertTo-Json | Set-Content -Path $CfgFile -Encoding UTF8
}

function Download($url, $out) {
    for ($i = 1; $i -le 3; $i++) {
        try {
            Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing
            return
        } catch {
            Warn "下載失敗（第 $i 次）：$($_.Exception.Message)"
            Start-Sleep -Seconds 2
        }
    }
    Fail "無法下載：$url`n       請檢查網路（或換下載來源）後重新執行。"
}

function Extract($zip, $dest) {
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
    if ($tar) {
        & tar.exe -xf $zip -C $dest
        if ($LASTEXITCODE -eq 0) { return }
        Warn '快速解壓失敗，改用備用方式（會比較慢）…'
    }
    Expand-Archive -Path $zip -DestinationPath $dest -Force
}

function Use-Node {
    if (-not (Test-Path $NodeExe)) { Fail '找不到 Node.js，請先執行「一鍵安裝.bat」。' }
    $env:Path = "$NodeDir;$env:Path"
}

function Has-Git { return [bool](Get-Command git -ErrorAction SilentlyContinue) }

# ---------- 安裝步驟 ----------
function Install-Node($mirror) {
    if (Test-Path $NodeExe) {
        Ok "Node.js 已存在（$(& $NodeExe -v)）"
        return
    }
    $base = if ($mirror) { 'https://npmmirror.com/mirrors/node' } else { 'https://nodejs.org/dist' }
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }

    Say '  取得 Node.js 最新 LTS 版本…'
    $index = $null
    for ($i = 1; $i -le 3 -and -not $index; $i++) {
        try { $index = Invoke-RestMethod -Uri "$base/index.json" -UseBasicParsing } catch { Start-Sleep -Seconds 2 }
    }
    if (-not $index) { Fail '無法取得 Node.js 版本清單，請檢查網路。' }

    $rel = $index | Where-Object { $_.lts -and ($_.files -contains "win-$arch-zip") } | Select-Object -First 1
    if (-not $rel) { Fail "找不到適合這台電腦（$arch）的 Node.js 版本。" }

    $ver  = $rel.version
    $name = "node-$ver-win-$arch"
    $zip  = Join-Path $TempDir "$name.zip"
    Say "  下載 Node.js $ver（約 30MB）…"
    Download "$base/$ver/$name.zip" $zip

    Say '  解壓縮 Node.js…'
    if (Test-Path $NodeDir) { Remove-Item $NodeDir -Recurse -Force }
    Extract $zip $Runtime
    Rename-Item -Path (Join-Path $Runtime $name) -NewName 'node'
    Ok "Node.js $ver 安裝完成（免安裝版，只放在這個資料夾裡）"
}

function Install-Tavern {
    if (Test-Path (Join-Path $TavernDir 'server.js')) {
        Ok '酒館已存在，略過下載'
        return
    }
    if (Test-Path $TavernDir) { Remove-Item $TavernDir -Recurse -Force }

    if (Has-Git) {
        Say '  偵測到 Git，用 Git 下載酒館（之後更新比較快）…'
        & git clone -b release --depth 1 $RepoGit $TavernDir
        if ($LASTEXITCODE -eq 0) { Ok '酒館下載完成'; return }
        Warn 'Git 下載失敗，改用壓縮檔下載…'
        if (Test-Path $TavernDir) { Remove-Item $TavernDir -Recurse -Force }
    }

    Say '  下載酒館（release 穩定版）…'
    $zip = Join-Path $TempDir 'SillyTavern.zip'
    Download $RepoZip $zip
    $x = Join-Path $TempDir 'st'
    if (Test-Path $x) { Remove-Item $x -Recurse -Force }
    Say '  解壓縮酒館…'
    Extract $zip $x
    $inner = Get-ChildItem $x -Directory | Select-Object -First 1
    Move-Item -Path $inner.FullName -Destination $TavernDir
    Ok '酒館下載完成'
}

function Npm-Install($mirror) {
    Push-Location $TavernDir
    $npmArgs = @('install', '--no-audit', '--no-fund', '--loglevel=error', '--no-progress', '--omit=dev')
    if ($mirror) { $npmArgs += '--registry=https://registry.npmmirror.com' }
    & $NpmCmd @npmArgs
    $code = $LASTEXITCODE
    Pop-Location
    if ($code -ne 0) { Fail '安裝酒館套件（npm install）失敗。請檢查網路後重試，或換下載來源。' }
}

function Make-Shortcut {
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $ws  = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut((Join-Path $desktop 'SillyTavern 酒館.lnk'))
        $lnk.TargetPath       = Join-Path $Root '啟動酒館.bat'
        $lnk.WorkingDirectory = $Root
        $ico = Join-Path $TavernDir 'public\favicon.ico'
        if (Test-Path $ico) { $lnk.IconLocation = $ico }
        $lnk.Save()
        Ok '已在桌面建立「SillyTavern 酒館」捷徑'
    } catch {
        Warn "建立捷徑失敗：$($_.Exception.Message)"
    }
}

function Backup-Data {
    $data = Join-Path $TavernDir 'data'
    if (-not (Test-Path $data)) { return }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
    $dest  = Join-Path $BackupDir "data-$stamp"
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Copy-Item -Path $data -Destination $dest -Recurse -Force
    $cfg = Join-Path $TavernDir 'config.yaml'
    if (Test-Path $cfg) { Copy-Item $cfg $dest -Force }
    Ok "已備份角色卡／聊天紀錄到 backups\data-$stamp"
}


# ---------- 手機連線 ----------
$LanRanges = @('192.168.0.0/16', '10.0.0.0/8', '172.16.0.0/12', '100.64.0.0/10')

function Get-ConfigText {
    $cfg = Join-Path $TavernDir 'config.yaml'
    if (-not (Test-Path $cfg)) {
        $def = Join-Path $TavernDir 'default\config.yaml'
        if (-not (Test-Path $def)) { Fail '找不到 config.yaml，請先啟動酒館一次再試。' }
        Copy-Item $def $cfg
    }
    return [IO.File]::ReadAllText($cfg)
}
function Set-ConfigText($text) {
    $cfg = Join-Path $TavernDir 'config.yaml'
    [IO.File]::WriteAllText($cfg, $text, (New-Object Text.UTF8Encoding($false)))
}

function Get-LanIPs {
    $ips = @()
    try {
        $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } |
            Select-Object -ExpandProperty IPAddress
    } catch {
        $ips = [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) |
            Where-Object { $_.AddressFamily -eq 'InterNetwork' -and $_.ToString() -notmatch '^(127\.|169\.254\.)' } |
            ForEach-Object { $_.ToString() }
    }
    return $ips
}

function Do-Lan {
    if (-not (Test-Path (Join-Path $TavernDir 'server.js'))) { Fail '還沒安裝酒館，請先執行「一鍵安裝.bat」。' }
    $backup = Join-Path $TavernDir 'config.yaml.before-lan'
    $text = Get-ConfigText
    if (-not (Test-Path $backup)) { [IO.File]::WriteAllText($backup, $text, (New-Object Text.UTF8Encoding($false))) }

    $text = [regex]::Replace($text, '(?m)^listen:\s*false', 'listen: true')
    if ($text -notmatch '(?m)^listen:') { $text = "listen: true`n" + $text }
    $text = [regex]::Replace($text, '(?m)^whitelistMode:\s*false', 'whitelistMode: true')

    $add = ''
    foreach ($r in $LanRanges) {
        if ($text -notmatch [regex]::Escape($r)) { $add += "`n  - $r" }
    }
    if ($add) {
        if ($text -match '(?m)^whitelist:[ \t]*\r?$') {
            $text = [regex]::Replace($text, '(?m)^whitelist:[ \t]*\r?$', { param($m) $m.Value.TrimEnd("`r") + $add }, 1)
        } else {
            $text += "`nwhitelist:`n  - ::1`n  - 127.0.0.1$add`n"
        }
    }
    Set-ConfigText $text
    Ok '已開放同一個 Wi-Fi（和 Tailscale）裡的裝置連線'

    Write-Host ''
    Say '手機（iPhone / iPad / 其他手機）用瀏覽器輸入下面任一個網址：' 'Green'
    $ips = Get-LanIPs
    if (-not $ips) { Warn '找不到這台電腦的區網 IP，請確認有連上網路。' }
    foreach ($ip in $ips) {
        $tag = if ($ip -match '^100\.') { '（Tailscale，出門也能連）' } elseif ($ip -match '^192\.168\.') { '（家裡 Wi-Fi，最常用這個）' } else { '' }
        Write-Host "    http://$($ip):8000  $tag" -ForegroundColor White
    }
    Write-Host ''
    Say '注意：' 'Yellow'
    Write-Host '  1. 手機要和電腦連同一個 Wi-Fi'
    Write-Host '  2. 酒館要開著（雙擊「啟動酒館.bat」）'
    Write-Host '  3. 第一次啟動若跳出「Windows 安全性警訊」，兩個網路都勾選再按「允許存取」'
    Write-Host '  4. 想關掉：雙擊「關閉手機連線.bat」'
    Write-Host ''
    $go = Read-Host '現在就啟動酒館嗎？(Y/n)'
    if ($go -notmatch '^[nN]') { Do-Start }
}

function Do-LanOff {
    $backup = Join-Path $TavernDir 'config.yaml.before-lan'
    if (Test-Path $backup) {
        Copy-Item $backup (Join-Path $TavernDir 'config.yaml') -Force
        Remove-Item $backup -Force
    } else {
        $text = Get-ConfigText
        $text = [regex]::Replace($text, '(?m)^listen:\s*true', 'listen: false')
        Set-ConfigText $text
    }
    Ok '已關閉手機連線，現在只有這台電腦能開酒館。重新啟動酒館後生效。'
}

# ---------- 主要動作 ----------
function Do-Install {
    Clear-Host
    Say '=============================================' 'Magenta'
    Say '        SillyTavern 酒館 一鍵安裝' 'Magenta'
    Say '=============================================' 'Magenta'
    Write-Host ''
    if ($Root -match 'Program Files') {
        Warn '一鍵包放在 Program Files 裡可能沒有寫入權限，建議移到 D:\ 或桌面再執行。'
    }

    Write-Host '選擇下載來源：'
    Write-Host '  [1] 官方來源（台灣／海外，預設）'
    Write-Host '  [2] 中國大陸鏡像（Node.js 和套件走 npmmirror）'
    $choice = Read-Host '輸入 1 或 2 後按 Enter'
    $settings = Load-Settings
    $settings.mirror = ($choice -eq '2')
    Save-Settings $settings
    $mirror = $settings.mirror

    New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

    Write-Host ''; Say '[1/3] 準備 Node.js'
    Install-Node $mirror
    Use-Node

    Write-Host ''; Say '[2/3] 下載酒館'
    Install-Tavern

    Write-Host ''; Say '[3/3] 安裝酒館需要的套件（第一次會久一點）'
    Npm-Install $mirror
    Ok '套件安裝完成'

    Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host ''
    $sc = Read-Host '要在桌面建立啟動捷徑嗎？(Y/n)'
    if ($sc -notmatch '^[nN]') { Make-Shortcut }

    Write-Host ''
    Say '=============================================' 'Green'
    Say '   安裝完成！之後雙擊「啟動酒館.bat」就能開。' 'Green'
    Say '=============================================' 'Green'
    Write-Host ''
    $go = Read-Host '現在就啟動酒館嗎？(Y/n)'
    if ($go -notmatch '^[nN]') { Do-Start }
}

function Do-Start {
    if (-not (Test-Path (Join-Path $TavernDir 'server.js'))) { Fail '還沒安裝酒館，請先執行「一鍵安裝.bat」。' }
    Use-Node
    $settings = Load-Settings
    Say '檢查套件…'
    Npm-Install $settings.mirror
    Write-Host ''
    Say '酒館啟動中… 瀏覽器會自動打開 http://127.0.0.1:8000' 'Green'
    Say '（要關閉酒館，直接關掉這個黑色視窗就好）' 'Yellow'
    Write-Host ''
    Push-Location $TavernDir
    & $NodeExe server.js
    Pop-Location
}

function Do-Update {
    if (-not (Test-Path (Join-Path $TavernDir 'server.js'))) { Fail '還沒安裝酒館，請先執行「一鍵安裝.bat」。' }
    Use-Node
    $settings = Load-Settings
    Say '更新前先備份你的資料…'
    Backup-Data

    if ((Test-Path (Join-Path $TavernDir '.git')) -and (Has-Git)) {
        Say '用 Git 更新酒館…'
        Push-Location $TavernDir
        & git pull --ff-only
        $code = $LASTEXITCODE
        Pop-Location
        if ($code -ne 0) { Fail 'Git 更新失敗。你的資料已備份在 backups 資料夾。' }
    } else {
        New-Item -ItemType Directory -Force -Path $TempDir | Out-Null
        Say '下載最新版酒館…'
        $zip = Join-Path $TempDir 'SillyTavern.zip'
        Download $RepoZip $zip
        $x = Join-Path $TempDir 'st'
        if (Test-Path $x) { Remove-Item $x -Recurse -Force }
        Extract $zip $x
        $inner = Get-ChildItem $x -Directory | Select-Object -First 1
        Say '覆蓋程式檔案（不會動到 data 資料夾和 config.yaml）…'
        & robocopy $inner.FullName $TavernDir /E /XD data node_modules .git /XF config.yaml /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Fail '覆蓋檔案失敗。你的資料已備份在 backups 資料夾。' }
        Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }

    Say '更新套件…'
    Npm-Install $settings.mirror
    Write-Host ''
    Ok '更新完成！雙擊「啟動酒館.bat」就能用新版。'
}

switch ($Action) {
    'install' { Do-Install }
    'start'   { Do-Start }
    'update'  { Do-Update }
    'lan'     { Do-Lan }
    'lanoff'  { Do-LanOff }
}
