@echo off
title SillyTavern
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\tavern.ps1" start
echo.
pause
