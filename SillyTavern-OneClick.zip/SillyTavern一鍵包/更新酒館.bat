@echo off
title SillyTavern Updater
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\tavern.ps1" update
echo.
pause
