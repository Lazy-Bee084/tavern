@echo off
title SillyTavern LAN off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\tavern.ps1" lanoff
echo.
pause
